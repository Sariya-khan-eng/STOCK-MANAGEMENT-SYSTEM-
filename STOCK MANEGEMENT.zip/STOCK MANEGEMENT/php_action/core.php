<?php 

session_start();

require_once 'db_connect.php';

// echo "HI ". $_SESSION['userId'];

// if(!$_SESSION['userId']) {
// 	header('location:index.php');	
// } 



?>